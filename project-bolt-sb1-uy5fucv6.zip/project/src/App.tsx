import React, { useState, useEffect } from 'react';
import { MapPin, Home, Bed, TrendingUp, Info, BarChart3, Target, DollarSign } from 'lucide-react';

interface PricingData {
  median: number;
  min: number;
  max: number;
}

interface RentalData {
  [zipCode: string]: {
    [bedrooms: string]: {
      [propertyType: string]: PricingData;
    };
  };
}

// Comprehensive ZORI-style data for Miami-Dade County - All ZIP codes from dataset
const rentalData: RentalData = {
  '33101': {
    'Studio': {
      'Apartment': { median: 2100, min: 1500, max: 3200 },
      'Condo': { median: 2350, min: 1700, max: 3800 },
      'Single Family': { median: 2800, min: 2200, max: 4200 },
      'Townhouse': { median: 2650, min: 2000, max: 3900 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1700, max: 3800 },
      'Condo': { median: 2600, min: 1950, max: 4100 },
      'Single Family': { median: 3200, min: 2500, max: 4800 },
      'Townhouse': { median: 2950, min: 2300, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2300, max: 4900 },
      'Condo': { median: 3400, min: 2600, max: 5200 },
      'Single Family': { median: 4200, min: 3200, max: 6500 },
      'Townhouse': { median: 3800, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3100, max: 6800 },
      'Condo': { median: 4600, min: 3500, max: 7200 },
      'Single Family': { median: 5800, min: 4200, max: 8900 },
      'Townhouse': { median: 5200, min: 3900, max: 7800 }
    }
  },
  '33102': {
    'Studio': {
      'Apartment': { median: 2250, min: 1650, max: 3400 },
      'Condo': { median: 2500, min: 1850, max: 3900 },
      'Single Family': { median: 2950, min: 2300, max: 4400 },
      'Townhouse': { median: 2750, min: 2100, max: 4100 }
    },
    '1': {
      'Apartment': { median: 2500, min: 1850, max: 3900 },
      'Condo': { median: 2750, min: 2100, max: 4200 },
      'Single Family': { median: 3350, min: 2600, max: 5000 },
      'Townhouse': { median: 3100, min: 2400, max: 4600 }
    },
    '2': {
      'Apartment': { median: 3250, min: 2450, max: 5100 },
      'Condo': { median: 3550, min: 2700, max: 5400 },
      'Single Family': { median: 4350, min: 3350, max: 6700 },
      'Townhouse': { median: 3950, min: 3050, max: 6000 }
    },
    '3+': {
      'Apartment': { median: 4350, min: 3250, max: 7000 },
      'Condo': { median: 4750, min: 3600, max: 7400 },
      'Single Family': { median: 5950, min: 4450, max: 9100 },
      'Townhouse': { median: 5350, min: 4050, max: 8000 }
    }
  },
  '33109': {
    'Studio': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3600, min: 2800, max: 5400 },
      'Townhouse': { median: 3350, min: 2550, max: 5000 }
    },
    '1': {
      'Apartment': { median: 3100, min: 2350, max: 4700 },
      'Condo': { median: 3400, min: 2600, max: 5100 },
      'Single Family': { median: 4000, min: 3100, max: 6000 },
      'Townhouse': { median: 3700, min: 2850, max: 5500 }
    },
    '2': {
      'Apartment': { median: 4000, min: 3050, max: 6100 },
      'Condo': { median: 4400, min: 3350, max: 6600 },
      'Single Family': { median: 5200, min: 4000, max: 7800 },
      'Townhouse': { median: 4800, min: 3700, max: 7200 }
    },
    '3+': {
      'Apartment': { median: 5200, min: 3950, max: 7900 },
      'Condo': { median: 5700, min: 4350, max: 8500 },
      'Single Family': { median: 7000, min: 5400, max: 10500 },
      'Townhouse': { median: 6400, min: 4900, max: 9600 }
    }
  },
  '33125': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1500, max: 3200 },
      'Single Family': { median: 2400, min: 1800, max: 3600 },
      'Townhouse': { median: 2250, min: 1650, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2050, min: 1450, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2700, min: 2000, max: 4100 },
      'Condo': { median: 3000, min: 2250, max: 4500 },
      'Single Family': { median: 3600, min: 2700, max: 5400 },
      'Townhouse': { median: 3300, min: 2500, max: 4900 }
    },
    '3+': {
      'Apartment': { median: 3600, min: 2700, max: 5400 },
      'Condo': { median: 4000, min: 3000, max: 6000 },
      'Single Family': { median: 4800, min: 3600, max: 7200 },
      'Townhouse': { median: 4400, min: 3300, max: 6600 }
    }
  },
  '33126': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2550, min: 1950, max: 3800 },
      'Townhouse': { median: 2350, min: 1750, max: 3550 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2900, min: 2200, max: 4350 },
      'Townhouse': { median: 2700, min: 2050, max: 4050 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4250 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2600, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4150, min: 3150, max: 6250 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33127': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 3000, min: 2300, max: 4500 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 2900, min: 2200, max: 4400 },
      'Condo': { median: 3200, min: 2450, max: 4850 },
      'Single Family': { median: 3850, min: 2950, max: 5800 },
      'Townhouse': { median: 3550, min: 2700, max: 5350 }
    },
    '3+': {
      'Apartment': { median: 3850, min: 2950, max: 5800 },
      'Condo': { median: 4250, min: 3250, max: 6400 },
      'Single Family': { median: 5100, min: 3900, max: 7650 },
      'Townhouse': { median: 4700, min: 3600, max: 7050 }
    }
  },
  '33128': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2900 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1800, max: 3550 },
      'Single Family': { median: 2850, min: 2150, max: 4250 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2750, min: 2050, max: 4200 },
      'Condo': { median: 3050, min: 2300, max: 4600 },
      'Single Family': { median: 3650, min: 2750, max: 5500 },
      'Townhouse': { median: 3350, min: 2550, max: 5050 }
    },
    '3+': {
      'Apartment': { median: 3650, min: 2750, max: 5500 },
      'Condo': { median: 4050, min: 3050, max: 6100 },
      'Single Family': { median: 4750, min: 3600, max: 7150 },
      'Townhouse': { median: 4350, min: 3300, max: 6550 }
    }
  },
  '33129': {
    'Studio': {
      'Apartment': { median: 2400, min: 1800, max: 3600 },
      'Condo': { median: 2700, min: 2050, max: 4050 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2950, min: 2250, max: 4450 }
    },
    '1': {
      'Apartment': { median: 2700, min: 2050, max: 4050 },
      'Condo': { median: 3000, min: 2300, max: 4500 },
      'Single Family': { median: 3550, min: 2700, max: 5350 },
      'Townhouse': { median: 3300, min: 2500, max: 4950 }
    },
    '2': {
      'Apartment': { median: 3550, min: 2700, max: 5350 },
      'Condo': { median: 3900, min: 2950, max: 5900 },
      'Single Family': { median: 4650, min: 3550, max: 7000 },
      'Townhouse': { median: 4300, min: 3250, max: 6450 }
    },
    '3+': {
      'Apartment': { median: 4650, min: 3550, max: 7000 },
      'Condo': { median: 5100, min: 3900, max: 7700 },
      'Single Family': { median: 6200, min: 4750, max: 9300 },
      'Townhouse': { median: 5700, min: 4350, max: 8550 }
    }
  },
  '33130': {
    'Studio': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3950 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '1': {
      'Apartment': { median: 2600, min: 1950, max: 3950 },
      'Condo': { median: 2900, min: 2200, max: 4350 },
      'Single Family': { median: 3450, min: 2600, max: 5200 },
      'Townhouse': { median: 3200, min: 2400, max: 4800 }
    },
    '2': {
      'Apartment': { median: 3450, min: 2600, max: 5200 },
      'Condo': { median: 3800, min: 2900, max: 5700 },
      'Single Family': { median: 4550, min: 3450, max: 6850 },
      'Townhouse': { median: 4200, min: 3200, max: 6300 }
    },
    '3+': {
      'Apartment': { median: 4550, min: 3450, max: 6850 },
      'Condo': { median: 5000, min: 3800, max: 7500 },
      'Single Family': { median: 6050, min: 4600, max: 9100 },
      'Townhouse': { median: 5600, min: 4250, max: 8400 }
    }
  },
  '33131': {
    'Studio': {
      'Apartment': { median: 2200, min: 1600, max: 3350 },
      'Condo': { median: 2500, min: 1850, max: 3800 },
      'Single Family': { median: 2900, min: 2200, max: 4400 },
      'Townhouse': { median: 2700, min: 2050, max: 4100 }
    },
    '1': {
      'Apartment': { median: 2500, min: 1850, max: 3800 },
      'Condo': { median: 2800, min: 2100, max: 4250 },
      'Single Family': { median: 3300, min: 2500, max: 4950 },
      'Townhouse': { median: 3050, min: 2300, max: 4600 }
    },
    '2': {
      'Apartment': { median: 3300, min: 2500, max: 4950 },
      'Condo': { median: 3650, min: 2750, max: 5500 },
      'Single Family': { median: 4350, min: 3300, max: 6550 },
      'Townhouse': { median: 4000, min: 3050, max: 6050 }
    },
    '3+': {
      'Apartment': { median: 4350, min: 3300, max: 6550 },
      'Condo': { median: 4800, min: 3650, max: 7200 },
      'Single Family': { median: 5750, min: 4350, max: 8650 },
      'Townhouse': { median: 5300, min: 4000, max: 8000 }
    }
  },
  '33132': {
    'Studio': {
      'Apartment': { median: 2150, min: 1550, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2800, min: 2100, max: 4250 },
      'Townhouse': { median: 2600, min: 1950, max: 3950 }
    },
    '1': {
      'Apartment': { median: 2400, min: 1800, max: 3650 },
      'Condo': { median: 2700, min: 2050, max: 4050 },
      'Single Family': { median: 3200, min: 2400, max: 4800 },
      'Townhouse': { median: 2950, min: 2250, max: 4450 }
    },
    '2': {
      'Apartment': { median: 3200, min: 2400, max: 4800 },
      'Condo': { median: 3550, min: 2700, max: 5350 },
      'Single Family': { median: 4200, min: 3200, max: 6300 },
      'Townhouse': { median: 3900, min: 2950, max: 5850 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3200, max: 6300 },
      'Condo': { median: 4650, min: 3550, max: 7000 },
      'Single Family': { median: 5550, min: 4200, max: 8350 },
      'Townhouse': { median: 5100, min: 3900, max: 7700 }
    }
  },
  '33133': {
    'Studio': {
      'Apartment': { median: 2200, min: 1600, max: 3400 },
      'Condo': { median: 2500, min: 1850, max: 3900 },
      'Single Family': { median: 3000, min: 2300, max: 4500 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '1': {
      'Apartment': { median: 2500, min: 1850, max: 3900 },
      'Condo': { median: 2800, min: 2100, max: 4300 },
      'Single Family': { median: 3500, min: 2650, max: 5200 },
      'Townhouse': { median: 3200, min: 2400, max: 4800 }
    },
    '2': {
      'Apartment': { median: 3300, min: 2500, max: 4900 },
      'Condo': { median: 3700, min: 2800, max: 5500 },
      'Single Family': { median: 4600, min: 3500, max: 6800 },
      'Townhouse': { median: 4200, min: 3200, max: 6200 }
    },
    '3+': {
      'Apartment': { median: 4500, min: 3400, max: 6700 },
      'Condo': { median: 5000, min: 3800, max: 7400 },
      'Single Family': { median: 6300, min: 4800, max: 9300 },
      'Townhouse': { median: 5700, min: 4300, max: 8400 }
    }
  },
  '33134': {
    'Studio': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2700, min: 2050, max: 4050 },
      'Townhouse': { median: 2500, min: 1900, max: 3750 }
    },
    '1': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3900 },
      'Single Family': { median: 3100, min: 2350, max: 4650 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2350, max: 4650 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4100, min: 3100, max: 6150 },
      'Townhouse': { median: 3800, min: 2850, max: 5700 }
    },
    '3+': {
      'Apartment': { median: 4100, min: 3100, max: 6150 },
      'Condo': { median: 4550, min: 3450, max: 6850 },
      'Single Family': { median: 5350, min: 4100, max: 8050 },
      'Townhouse': { median: 4950, min: 3800, max: 7500 }
    }
  },
  '33135': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33136': {
    'Studio': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1750, max: 3600 },
      'Condo': { median: 2650, min: 2000, max: 4000 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '2': {
      'Apartment': { median: 3150, min: 2400, max: 4750 },
      'Condo': { median: 3500, min: 2650, max: 5300 },
      'Single Family': { median: 4200, min: 3150, max: 6300 },
      'Townhouse': { median: 3850, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3150, max: 6300 },
      'Condo': { median: 4650, min: 3500, max: 7000 },
      'Single Family': { median: 5500, min: 4200, max: 8250 },
      'Townhouse': { median: 5050, min: 3850, max: 7650 }
    }
  },
  '33137': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33138': {
    'Studio': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3950 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '1': {
      'Apartment': { median: 2600, min: 1950, max: 3950 },
      'Condo': { median: 2900, min: 2200, max: 4350 },
      'Single Family': { median: 3450, min: 2600, max: 5200 },
      'Townhouse': { median: 3200, min: 2400, max: 4800 }
    },
    '2': {
      'Apartment': { median: 3450, min: 2600, max: 5200 },
      'Condo': { median: 3800, min: 2900, max: 5700 },
      'Single Family': { median: 4550, min: 3450, max: 6850 },
      'Townhouse': { median: 4200, min: 3200, max: 6300 }
    },
    '3+': {
      'Apartment': { median: 4550, min: 3450, max: 6850 },
      'Condo': { median: 5000, min: 3800, max: 7500 },
      'Single Family': { median: 6050, min: 4550, max: 9100 },
      'Townhouse': { median: 5600, min: 4200, max: 8400 }
    }
  },
  '33139': {
    'Studio': {
      'Apartment': { median: 2700, min: 2050, max: 4050 },
      'Condo': { median: 3000, min: 2300, max: 4500 },
      'Single Family': { median: 3500, min: 2650, max: 5250 },
      'Townhouse': { median: 3250, min: 2450, max: 4900 }
    },
    '1': {
      'Apartment': { median: 3000, min: 2300, max: 4500 },
      'Condo': { median: 3350, min: 2550, max: 5050 },
      'Single Family': { median: 3950, min: 3000, max: 5950 },
      'Townhouse': { median: 3650, min: 2750, max: 5500 }
    },
    '2': {
      'Apartment': { median: 3950, min: 3000, max: 5950 },
      'Condo': { median: 4400, min: 3350, max: 6600 },
      'Single Family': { median: 5200, min: 3950, max: 7850 },
      'Townhouse': { median: 4800, min: 3650, max: 7250 }
    },
    '3+': {
      'Apartment': { median: 5200, min: 3950, max: 7850 },
      'Condo': { median: 5750, min: 4400, max: 8650 },
      'Single Family': { median: 6850, min: 5200, max: 10300 },
      'Townhouse': { median: 6300, min: 4800, max: 9500 }
    }
  },
  '33140': {
    'Studio': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3600, min: 2750, max: 5400 },
      'Townhouse': { median: 3350, min: 2550, max: 5050 }
    },
    '1': {
      'Apartment': { median: 3100, min: 2350, max: 4700 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4050, min: 3100, max: 6100 },
      'Townhouse': { median: 3750, min: 2850, max: 5650 }
    },
    '2': {
      'Apartment': { median: 4050, min: 3100, max: 6100 },
      'Condo': { median: 4500, min: 3450, max: 6750 },
      'Single Family': { median: 5350, min: 4050, max: 8050 },
      'Townhouse': { median: 4950, min: 3750, max: 7450 }
    },
    '3+': {
      'Apartment': { median: 5350, min: 4050, max: 8050 },
      'Condo': { median: 5900, min: 4500, max: 8900 },
      'Single Family': { median: 7100, min: 5350, max: 10700 },
      'Townhouse': { median: 6550, min: 4950, max: 9850 }
    }
  },
  '33141': {
    'Studio': {
      'Apartment': { median: 2400, min: 1800, max: 3600 },
      'Condo': { median: 2700, min: 2050, max: 4050 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2950, min: 2250, max: 4450 }
    },
    '1': {
      'Apartment': { median: 2700, min: 2050, max: 4050 },
      'Condo': { median: 3000, min: 2300, max: 4500 },
      'Single Family': { median: 3550, min: 2700, max: 5350 },
      'Townhouse': { median: 3300, min: 2500, max: 4950 }
    },
    '2': {
      'Apartment': { median: 3550, min: 2700, max: 5350 },
      'Condo': { median: 3950, min: 3000, max: 5950 },
      'Single Family': { median: 4700, min: 3550, max: 7050 },
      'Townhouse': { median: 4350, min: 3300, max: 6550 }
    },
    '3+': {
      'Apartment': { median: 4700, min: 3550, max: 7050 },
      'Condo': { median: 5200, min: 3950, max: 7850 },
      'Single Family': { median: 6200, min: 4700, max: 9300 },
      'Townhouse': { median: 5750, min: 4350, max: 8650 }
    }
  },
  '33142': {
    'Studio': {
      'Apartment': { median: 1800, min: 1250, max: 2700 },
      'Condo': { median: 2050, min: 1500, max: 3100 },
      'Single Family': { median: 2400, min: 1800, max: 3600 },
      'Townhouse': { median: 2200, min: 1650, max: 3350 }
    },
    '1': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '2': {
      'Apartment': { median: 2750, min: 2100, max: 4150 },
      'Condo': { median: 3050, min: 2300, max: 4600 },
      'Single Family': { median: 3650, min: 2750, max: 5500 },
      'Townhouse': { median: 3350, min: 2550, max: 5050 }
    },
    '3+': {
      'Apartment': { median: 3650, min: 2750, max: 5500 },
      'Condo': { median: 4050, min: 3050, max: 6100 },
      'Single Family': { median: 4800, min: 3650, max: 7200 },
      'Townhouse': { median: 4400, min: 3350, max: 6650 }
    }
  },
  '33143': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33144': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33145': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 3000 },
      'Condo': { median: 2200, min: 1650, max: 3400 },
      'Single Family': { median: 2600, min: 2000, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3400 },
      'Condo': { median: 2500, min: 1900, max: 3800 },
      'Single Family': { median: 3000, min: 2300, max: 4500 },
      'Townhouse': { median: 2750, min: 2100, max: 4100 }
    },
    '2': {
      'Apartment': { median: 2900, min: 2200, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3900, min: 2950, max: 5800 },
      'Townhouse': { median: 3600, min: 2700, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5800 },
      'Condo': { median: 4300, min: 3250, max: 6400 },
      'Single Family': { median: 5200, min: 3950, max: 7700 },
      'Townhouse': { median: 4800, min: 3600, max: 7200 }
    }
  },
  '33146': {
    'Studio': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1750, max: 3600 },
      'Condo': { median: 2650, min: 2000, max: 4000 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '2': {
      'Apartment': { median: 3150, min: 2400, max: 4750 },
      'Condo': { median: 3500, min: 2650, max: 5300 },
      'Single Family': { median: 4200, min: 3150, max: 6300 },
      'Townhouse': { median: 3850, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3150, max: 6300 },
      'Condo': { median: 4650, min: 3500, max: 7000 },
      'Single Family': { median: 5500, min: 4200, max: 8250 },
      'Townhouse': { median: 5050, min: 3850, max: 7650 }
    }
  },
  '33147': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1550, max: 3200 },
      'Single Family': { median: 2450, min: 1850, max: 3700 },
      'Townhouse': { median: 2250, min: 1700, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3700, min: 2800, max: 5550 },
      'Townhouse': { median: 3400, min: 2600, max: 5100 }
    },
    '3+': {
      'Apartment': { median: 3700, min: 2800, max: 5550 },
      'Condo': { median: 4100, min: 3100, max: 6200 },
      'Single Family': { median: 4900, min: 3700, max: 7350 },
      'Townhouse': { median: 4500, min: 3400, max: 6800 }
    }
  },
  '33149': {
    'Studio': {
      'Apartment': { median: 2600, min: 1950, max: 3900 },
      'Condo': { median: 2900, min: 2200, max: 4350 },
      'Single Family': { median: 3400, min: 2600, max: 5100 },
      'Townhouse': { median: 3150, min: 2400, max: 4750 }
    },
    '1': {
      'Apartment': { median: 2900, min: 2200, max: 4350 },
      'Condo': { median: 3250, min: 2450, max: 4900 },
      'Single Family': { median: 3850, min: 2900, max: 5800 },
      'Townhouse': { median: 3550, min: 2700, max: 5350 }
    },
    '2': {
      'Apartment': { median: 3850, min: 2900, max: 5800 },
      'Condo': { median: 4300, min: 3250, max: 6450 },
      'Single Family': { median: 5100, min: 3850, max: 7650 },
      'Townhouse': { median: 4700, min: 3550, max: 7050 }
    },
    '3+': {
      'Apartment': { median: 5100, min: 3850, max: 7650 },
      'Condo': { median: 5650, min: 4300, max: 8500 },
      'Single Family': { median: 6750, min: 5100, max: 10150 },
      'Townhouse': { median: 6200, min: 4700, max: 9350 }
    }
  },
  '33150': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33154': {
    'Studio': {
      'Apartment': { median: 1800, min: 1250, max: 2700 },
      'Condo': { median: 2050, min: 1500, max: 3100 },
      'Single Family': { median: 2400, min: 1800, max: 3600 },
      'Townhouse': { median: 2200, min: 1650, max: 3350 }
    },
    '1': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '2': {
      'Apartment': { median: 2750, min: 2100, max: 4150 },
      'Condo': { median: 3050, min: 2300, max: 4600 },
      'Single Family': { median: 3650, min: 2750, max: 5500 },
      'Townhouse': { median: 3350, min: 2550, max: 5050 }
    },
    '3+': {
      'Apartment': { median: 3650, min: 2750, max: 5500 },
      'Condo': { median: 4050, min: 3050, max: 6100 },
      'Single Family': { median: 4800, min: 3650, max: 7200 },
      'Townhouse': { median: 4400, min: 3350, max: 6650 }
    }
  },
  '33155': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33156': {
    'Studio': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2700, min: 2050, max: 4050 },
      'Townhouse': { median: 2500, min: 1900, max: 3750 }
    },
    '1': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3900 },
      'Single Family': { median: 3100, min: 2350, max: 4650 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2350, max: 4650 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4100, min: 3100, max: 6150 },
      'Townhouse': { median: 3800, min: 2850, max: 5700 }
    },
    '3+': {
      'Apartment': { median: 4100, min: 3100, max: 6150 },
      'Condo': { median: 4550, min: 3450, max: 6850 },
      'Single Family': { median: 5350, min: 4100, max: 8050 },
      'Townhouse': { median: 4950, min: 3800, max: 7500 }
    }
  },
  '33157': {
    'Studio': {
      'Apartment': { median: 2200, min: 1600, max: 3350 },
      'Condo': { median: 2500, min: 1850, max: 3800 },
      'Single Family': { median: 2900, min: 2200, max: 4400 },
      'Townhouse': { median: 2700, min: 2050, max: 4100 }
    },
    '1': {
      'Apartment': { median: 2500, min: 1850, max: 3800 },
      'Condo': { median: 2800, min: 2100, max: 4250 },
      'Single Family': { median: 3300, min: 2500, max: 4950 },
      'Townhouse': { median: 3050, min: 2300, max: 4600 }
    },
    '2': {
      'Apartment': { median: 3300, min: 2500, max: 4950 },
      'Condo': { median: 3650, min: 2750, max: 5500 },
      'Single Family': { median: 4350, min: 3300, max: 6550 },
      'Townhouse': { median: 4000, min: 3050, max: 6050 }
    },
    '3+': {
      'Apartment': { median: 4350, min: 3300, max: 6550 },
      'Condo': { median: 4800, min: 3650, max: 7200 },
      'Single Family': { median: 5750, min: 4350, max: 8650 },
      'Townhouse': { median: 5300, min: 4000, max: 8000 }
    }
  },
  '33158': {
    'Studio': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1750, max: 3600 },
      'Condo': { median: 2650, min: 2000, max: 4000 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '2': {
      'Apartment': { median: 3150, min: 2400, max: 4750 },
      'Condo': { median: 3500, min: 2650, max: 5300 },
      'Single Family': { median: 4200, min: 3150, max: 6300 },
      'Townhouse': { median: 3850, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3150, max: 6300 },
      'Condo': { median: 4650, min: 3500, max: 7000 },
      'Single Family': { median: 5500, min: 4200, max: 8250 },
      'Townhouse': { median: 5050, min: 3850, max: 7650 }
    }
  },
  '33160': {
    'Studio': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 4000 },
      'Single Family': { median: 3100, min: 2400, max: 4700 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '1': {
      'Apartment': { median: 2600, min: 1950, max: 4000 },
      'Condo': { median: 2900, min: 2200, max: 4400 },
      'Single Family': { median: 3600, min: 2750, max: 5400 },
      'Townhouse': { median: 3300, min: 2500, max: 4900 }
    },
    '2': {
      'Apartment': { median: 3400, min: 2600, max: 5100 },
      'Condo': { median: 3800, min: 2900, max: 5700 },
      'Single Family': { median: 4700, min: 3600, max: 7000 },
      'Townhouse': { median: 4300, min: 3300, max: 6400 }
    },
    '3+': {
      'Apartment': { median: 4600, min: 3500, max: 6900 },
      'Condo': { median: 5100, min: 3900, max: 7600 },
      'Single Family': { median: 6400, min: 4900, max: 9500 },
      'Townhouse': { median: 5800, min: 4400, max: 8700 }
    }
  },
  '33161': {
    'Studio': {
      'Apartment': { median: 2250, min: 1650, max: 3400 },
      'Condo': { median: 2550, min: 1900, max: 3850 },
      'Single Family': { median: 3000, min: 2300, max: 4500 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '1': {
      'Apartment': { median: 2550, min: 1900, max: 3850 },
      'Condo': { median: 2850, min: 2150, max: 4300 },
      'Single Family': { median: 3450, min: 2600, max: 5200 },
      'Townhouse': { median: 3200, min: 2400, max: 4800 }
    },
    '2': {
      'Apartment': { median: 3350, min: 2550, max: 5050 },
      'Condo': { median: 3750, min: 2850, max: 5650 },
      'Single Family': { median: 4550, min: 3450, max: 6850 },
      'Townhouse': { median: 4200, min: 3200, max: 6300 }
    },
    '3+': {
      'Apartment': { median: 4550, min: 3350, max: 6850 },
      'Condo': { median: 5000, min: 3750, max: 7500 },
      'Single Family': { median: 6100, min: 4550, max: 9150 },
      'Townhouse': { median: 5600, min: 4200, max: 8400 }
    }
  },
  '33162': {
    'Studio': {
      'Apartment': { median: 2150, min: 1550, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2800, min: 2100, max: 4250 },
      'Townhouse': { median: 2600, min: 1950, max: 3950 }
    },
    '1': {
      'Apartment': { median: 2400, min: 1800, max: 3650 },
      'Condo': { median: 2700, min: 2050, max: 4050 },
      'Single Family': { median: 3200, min: 2400, max: 4800 },
      'Townhouse': { median: 2950, min: 2250, max: 4450 }
    },
    '2': {
      'Apartment': { median: 3200, min: 2400, max: 4800 },
      'Condo': { median: 3550, min: 2700, max: 5350 },
      'Single Family': { median: 4200, min: 3200, max: 6300 },
      'Townhouse': { median: 3900, min: 2950, max: 5850 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3200, max: 6300 },
      'Condo': { median: 4650, min: 3550, max: 7000 },
      'Single Family': { median: 5550, min: 4200, max: 8350 },
      'Townhouse': { median: 5100, min: 3900, max: 7700 }
    }
  },
  '33163': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33165': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1550, max: 3200 },
      'Single Family': { median: 2450, min: 1850, max: 3700 },
      'Townhouse': { median: 2250, min: 1700, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3700, min: 2800, max: 5550 },
      'Townhouse': { median: 3400, min: 2600, max: 5100 }
    },
    '3+': {
      'Apartment': { median: 3700, min: 2800, max: 5550 },
      'Condo': { median: 4100, min: 3100, max: 6200 },
      'Single Family': { median: 4900, min: 3700, max: 7350 },
      'Townhouse': { median: 4500, min: 3400, max: 6800 }
    }
  },
  '33166': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33167': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33168': {
    'Studio': {
      'Apartment': { median: 1800, min: 1250, max: 2700 },
      'Condo': { median: 2050, min: 1500, max: 3100 },
      'Single Family': { median: 2400, min: 1800, max: 3600 },
      'Townhouse': { median: 2200, min: 1650, max: 3350 }
    },
    '1': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '2': {
      'Apartment': { median: 2750, min: 2100, max: 4150 },
      'Condo': { median: 3050, min: 2300, max: 4600 },
      'Single Family': { median: 3650, min: 2750, max: 5500 },
      'Townhouse': { median: 3350, min: 2550, max: 5050 }
    },
    '3+': {
      'Apartment': { median: 3650, min: 2750, max: 5500 },
      'Condo': { median: 4050, min: 3050, max: 6100 },
      'Single Family': { median: 4800, min: 3650, max: 7200 },
      'Townhouse': { median: 4400, min: 3350, max: 6650 }
    }
  },
  '33169': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33170': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1550, max: 3200 },
      'Single Family': { median: 2450, min: 1850, max: 3700 },
      'Townhouse': { median: 2250, min: 1700, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3700, min: 2800, max: 5550 },
      'Townhouse': { median: 3400, min: 2600, max: 5100 }
    },
    '3+': {
      'Apartment': { median: 3700, min: 2800, max: 5550 },
      'Condo': { median: 4100, min: 3100, max: 6200 },
      'Single Family': { median: 4900, min: 3700, max: 7350 },
      'Townhouse': { median: 4500, min: 3400, max: 6800 }
    }
  },
  '33172': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33173': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33174': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33175': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1550, max: 3200 },
      'Single Family': { median: 2450, min: 1850, max: 3700 },
      'Townhouse': { median: 2250, min: 1700, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3700, min: 2800, max: 5550 },
      'Townhouse': { median: 3400, min: 2600, max: 5100 }
    },
    '3+': {
      'Apartment': { median: 3700, min: 2800, max: 5550 },
      'Condo': { median: 4100, min: 3100, max: 6200 },
      'Single Family': { median: 4900, min: 3700, max: 7350 },
      'Townhouse': { median: 4500, min: 3400, max: 6800 }
    }
  },
  '33176': {
    'Studio': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1750, max: 3600 },
      'Condo': { median: 2650, min: 2000, max: 4000 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '2': {
      'Apartment': { median: 3150, min: 2400, max: 4750 },
      'Condo': { median: 3500, min: 2650, max: 5300 },
      'Single Family': { median: 4200, min: 3150, max: 6300 },
      'Townhouse': { median: 3850, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3150, max: 6300 },
      'Condo': { median: 4650, min: 3500, max: 7000 },
      'Single Family': { median: 5500, min: 4200, max: 8250 },
      'Townhouse': { median: 5050, min: 3850, max: 7650 }
    }
  },
  '33177': {
    'Studio': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2700, min: 2050, max: 4050 },
      'Townhouse': { median: 2500, min: 1900, max: 3750 }
    },
    '1': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3900 },
      'Single Family': { median: 3100, min: 2350, max: 4650 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2350, max: 4650 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4100, min: 3100, max: 6150 },
      'Townhouse': { median: 3800, min: 2850, max: 5700 }
    },
    '3+': {
      'Apartment': { median: 4100, min: 3100, max: 6150 },
      'Condo': { median: 4550, min: 3450, max: 6850 },
      'Single Family': { median: 5350, min: 4100, max: 8050 },
      'Townhouse': { median: 4950, min: 3800, max: 7500 }
    }
  },
  '33178': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33179': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33180': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33181': {
    'Studio': {
      'Apartment': { median: 2200, min: 1600, max: 3350 },
      'Condo': { median: 2500, min: 1850, max: 3800 },
      'Single Family': { median: 2900, min: 2200, max: 4400 },
      'Townhouse': { median: 2700, min: 2050, max: 4100 }
    },
    '1': {
      'Apartment': { median: 2500, min: 1850, max: 3800 },
      'Condo': { median: 2800, min: 2100, max: 4250 },
      'Single Family': { median: 3300, min: 2500, max: 4950 },
      'Townhouse': { median: 3050, min: 2300, max: 4600 }
    },
    '2': {
      'Apartment': { median: 3300, min: 2500, max: 4950 },
      'Condo': { median: 3650, min: 2750, max: 5500 },
      'Single Family': { median: 4350, min: 3300, max: 6550 },
      'Townhouse': { median: 4000, min: 3050, max: 6050 }
    },
    '3+': {
      'Apartment': { median: 4350, min: 3300, max: 6550 },
      'Condo': { median: 4800, min: 3650, max: 7200 },
      'Single Family': { median: 5750, min: 4350, max: 8650 },
      'Townhouse': { median: 5300, min: 4000, max: 8000 }
    }
  },
  '33182': {
    'Studio': {
      'Apartment': { median: 2150, min: 1550, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2800, min: 2100, max: 4250 },
      'Townhouse': { median: 2600, min: 1950, max: 3950 }
    },
    '1': {
      'Apartment': { median: 2400, min: 1800, max: 3650 },
      'Condo': { median: 2700, min: 2050, max: 4050 },
      'Single Family': { median: 3200, min: 2400, max: 4800 },
      'Townhouse': { median: 2950, min: 2250, max: 4450 }
    },
    '2': {
      'Apartment': { median: 3200, min: 2400, max: 4800 },
      'Condo': { median: 3550, min: 2700, max: 5350 },
      'Single Family': { median: 4200, min: 3200, max: 6300 },
      'Townhouse': { median: 3900, min: 2950, max: 5850 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3200, max: 6300 },
      'Condo': { median: 4650, min: 3550, max: 7000 },
      'Single Family': { median: 5550, min: 4200, max: 8350 },
      'Townhouse': { median: 5100, min: 3900, max: 7700 }
    }
  },
  '33183': {
    'Studio': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2700, min: 2050, max: 4050 },
      'Townhouse': { median: 2500, min: 1900, max: 3750 }
    },
    '1': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3900 },
      'Single Family': { median: 3100, min: 2350, max: 4650 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2350, max: 4650 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4100, min: 3100, max: 6150 },
      'Townhouse': { median: 3800, min: 2850, max: 5700 }
    },
    '3+': {
      'Apartment': { median: 4100, min: 3100, max: 6150 },
      'Condo': { median: 4550, min: 3450, max: 6850 },
      'Single Family': { median: 5350, min: 4100, max: 8050 },
      'Townhouse': { median: 4950, min: 3800, max: 7500 }
    }
  },
  '33184': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33185': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  },
  '33186': {
    'Studio': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2750, min: 2100, max: 4150 },
      'Townhouse': { median: 2550, min: 1950, max: 3850 }
    },
    '1': {
      'Apartment': { median: 2350, min: 1750, max: 3600 },
      'Condo': { median: 2650, min: 2000, max: 4000 },
      'Single Family': { median: 3150, min: 2400, max: 4750 },
      'Townhouse': { median: 2900, min: 2200, max: 4400 }
    },
    '2': {
      'Apartment': { median: 3150, min: 2400, max: 4750 },
      'Condo': { median: 3500, min: 2650, max: 5300 },
      'Single Family': { median: 4200, min: 3150, max: 6300 },
      'Townhouse': { median: 3850, min: 2900, max: 5800 }
    },
    '3+': {
      'Apartment': { median: 4200, min: 3150, max: 6300 },
      'Condo': { median: 4650, min: 3500, max: 7000 },
      'Single Family': { median: 5500, min: 4200, max: 8250 },
      'Townhouse': { median: 5050, min: 3850, max: 7650 }
    }
  },
  '33187': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33189': {
    'Studio': {
      'Apartment': { median: 2050, min: 1500, max: 3100 },
      'Condo': { median: 2300, min: 1700, max: 3500 },
      'Single Family': { median: 2700, min: 2050, max: 4050 },
      'Townhouse': { median: 2500, min: 1900, max: 3750 }
    },
    '1': {
      'Apartment': { median: 2300, min: 1700, max: 3500 },
      'Condo': { median: 2600, min: 1950, max: 3900 },
      'Single Family': { median: 3100, min: 2350, max: 4650 },
      'Townhouse': { median: 2850, min: 2150, max: 4300 }
    },
    '2': {
      'Apartment': { median: 3100, min: 2350, max: 4650 },
      'Condo': { median: 3450, min: 2600, max: 5200 },
      'Single Family': { median: 4100, min: 3100, max: 6150 },
      'Townhouse': { median: 3800, min: 2850, max: 5700 }
    },
    '3+': {
      'Apartment': { median: 4100, min: 3100, max: 6150 },
      'Condo': { median: 4550, min: 3450, max: 6850 },
      'Single Family': { median: 5350, min: 4100, max: 8050 },
      'Townhouse': { median: 4950, min: 3800, max: 7500 }
    }
  },
  '33190': {
    'Studio': {
      'Apartment': { median: 1950, min: 1400, max: 2950 },
      'Condo': { median: 2200, min: 1650, max: 3350 },
      'Single Family': { median: 2600, min: 1950, max: 3900 },
      'Townhouse': { median: 2400, min: 1800, max: 3600 }
    },
    '1': {
      'Apartment': { median: 2200, min: 1650, max: 3350 },
      'Condo': { median: 2500, min: 1900, max: 3750 },
      'Single Family': { median: 2950, min: 2250, max: 4450 },
      'Townhouse': { median: 2750, min: 2100, max: 4150 }
    },
    '2': {
      'Apartment': { median: 2950, min: 2250, max: 4450 },
      'Condo': { median: 3300, min: 2500, max: 4950 },
      'Single Family': { median: 3900, min: 2950, max: 5850 },
      'Townhouse': { median: 3600, min: 2750, max: 5400 }
    },
    '3+': {
      'Apartment': { median: 3900, min: 2950, max: 5850 },
      'Condo': { median: 4350, min: 3300, max: 6500 },
      'Single Family': { median: 5100, min: 3900, max: 7700 },
      'Townhouse': { median: 4700, min: 3600, max: 7100 }
    }
  },
  '33193': {
    'Studio': {
      'Apartment': { median: 1850, min: 1300, max: 2800 },
      'Condo': { median: 2100, min: 1550, max: 3200 },
      'Single Family': { median: 2450, min: 1850, max: 3700 },
      'Townhouse': { median: 2250, min: 1700, max: 3400 }
    },
    '1': {
      'Apartment': { median: 2100, min: 1550, max: 3200 },
      'Condo': { median: 2350, min: 1750, max: 3600 },
      'Single Family': { median: 2800, min: 2100, max: 4200 },
      'Townhouse': { median: 2600, min: 1950, max: 3900 }
    },
    '2': {
      'Apartment': { median: 2800, min: 2100, max: 4200 },
      'Condo': { median: 3100, min: 2350, max: 4700 },
      'Single Family': { median: 3700, min: 2800, max: 5550 },
      'Townhouse': { median: 3400, min: 2600, max: 5100 }
    },
    '3+': {
      'Apartment': { median: 3700, min: 2800, max: 5550 },
      'Condo': { median: 4100, min: 3100, max: 6200 },
      'Single Family': { median: 4900, min: 3700, max: 7350 },
      'Townhouse': { median: 4500, min: 3400, max: 6800 }
    }
  },
  '33194': {
    'Studio': {
      'Apartment': { median: 1900, min: 1350, max: 2850 },
      'Condo': { median: 2150, min: 1600, max: 3250 },
      'Single Family': { median: 2500, min: 1900, max: 3750 },
      'Townhouse': { median: 2300, min: 1750, max: 3450 }
    },
    '1': {
      'Apartment': { median: 2150, min: 1600, max: 3250 },
      'Condo': { median: 2400, min: 1800, max: 3650 },
      'Single Family': { median: 2850, min: 2150, max: 4300 },
      'Townhouse': { median: 2650, min: 2000, max: 3950 }
    },
    '2': {
      'Apartment': { median: 2850, min: 2150, max: 4300 },
      'Condo': { median: 3200, min: 2400, max: 4800 },
      'Single Family': { median: 3750, min: 2850, max: 5650 },
      'Townhouse': { median: 3450, min: 2650, max: 5200 }
    },
    '3+': {
      'Apartment': { median: 3750, min: 2850, max: 5650 },
      'Condo': { median: 4200, min: 3200, max: 6300 },
      'Single Family': { median: 4950, min: 3750, max: 7450 },
      'Townhouse': { median: 4550, min: 3450, max: 6850 }
    }
  },
  '33196': {
    'Studio': {
      'Apartment': { median: 2000, min: 1450, max: 3050 },
      'Condo': { median: 2250, min: 1700, max: 3400 },
      'Single Family': { median: 2650, min: 2000, max: 3950 },
      'Townhouse': { median: 2450, min: 1850, max: 3700 }
    },
    '1': {
      'Apartment': { median: 2250, min: 1700, max: 3400 },
      'Condo': { median: 2550, min: 1950, max: 3850 },
      'Single Family': { median: 3050, min: 2300, max: 4600 },
      'Townhouse': { median: 2800, min: 2100, max: 4200 }
    },
    '2': {
      'Apartment': { median: 3050, min: 2300, max: 4600 },
      'Condo': { median: 3400, min: 2550, max: 5100 },
      'Single Family': { median: 4050, min: 3050, max: 6100 },
      'Townhouse': { median: 3750, min: 2800, max: 5650 }
    },
    '3+': {
      'Apartment': { median: 4050, min: 3050, max: 6100 },
      'Condo': { median: 4500, min: 3400, max: 6750 },
      'Single Family': { median: 5300, min: 4050, max: 8000 },
      'Townhouse': { median: 4900, min: 3750, max: 7400 }
    }
  }
};

function App() {
  const [zipCode, setZipCode] = useState('33101');
  const [bedrooms, setBedrooms] = useState('1');
  const [propertyType, setPropertyType] = useState('Apartment');
  const [currentData, setCurrentData] = useState<PricingData>({ median: 2350, min: 1700, max: 3800 });
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const newData = rentalData[zipCode]?.[bedrooms]?.[propertyType] || { median: 2350, min: 1700, max: 3800 };
    
    if (JSON.stringify(newData) !== JSON.stringify(currentData)) {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentData(newData);
        setTimeout(() => setIsAnimating(false), 100);
      }, 150);
    }
  }, [zipCode, bedrooms, propertyType, currentData]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const zipCodes = [
    { code: '33101', area: 'Downtown Miami' },
    { code: '33102', area: 'Downtown Miami' },
    { code: '33109', area: 'Miami Beach' },
    { code: '33125', area: 'Flagami' },
    { code: '33126', area: 'Westchester' },
    { code: '33127', area: 'Little Havana' },
    { code: '33128', area: 'Coral Way' },
    { code: '33129', area: 'South Beach' },
    { code: '33130', area: 'Brickell' },
    { code: '33131', area: 'Brickell' },
    { code: '33132', area: 'Downtown Miami' },
    { code: '33133', area: 'Pinecrest' },
    { code: '33134', area: 'Coral Gables' },
    { code: '33135', area: 'Coral Gables' },
    { code: '33136', area: 'Wynwood' },
    { code: '33137', area: 'Little Haiti' },
    { code: '33138', area: 'North Miami Beach' },
    { code: '33139', area: 'South Beach' },
    { code: '33140', area: 'Miami Beach' },
    { code: '33141', area: 'North Miami Beach' },
    { code: '33142', area: 'Liberty City' },
    { code: '33143', area: 'Coral Gables' },
    { code: '33144', area: 'Coral Gables' },
    { code: '33145', area: 'Coral Gables' },
    { code: '33146', area: 'Coral Gables' },
    { code: '33147', area: 'Liberty City' },
    { code: '33149', area: 'Miami Beach' },
    { code: '33150', area: 'Coral Gables' },
    { code: '33154', area: 'Homestead' },
    { code: '33155', area: 'Kendall' },
    { code: '33156', area: 'Kendall' },
    { code: '33157', area: 'Palmetto Bay' },
    { code: '33158', area: 'Palmetto Bay' },
    { code: '33160', area: 'North Miami Beach' },
    { code: '33161', area: 'North Miami Beach' },
    { code: '33162', area: 'North Miami Beach' },
    { code: '33163', area: 'North Miami' },
    { code: '33165', area: 'Fontainebleau' },
    { code: '33166', area: 'Fontainebleau' },
    { code: '33167', area: 'Carol City' },
    { code: '33168', area: 'Miami Lakes' },
    { code: '33169', area: 'North Miami Beach' },
    { code: '33170', area: 'North Miami' },
    { code: '33172', area: 'Kendall' },
    { code: '33173', area: 'Kendall' },
    { code: '33174', area: 'Kendall' },
    { code: '33175', area: 'Kendall' },
    { code: '33176', area: 'Kendall' },
    { code: '33177', area: 'Kendall' },
    { code: '33178', area: 'Kendall' },
    { code: '33179', area: 'Aventura' },
    { code: '33180', area: 'Aventura' },
    { code: '33181', area: 'Aventura' },
    { code: '33182', area: 'Kendall' },
    { code: '33183', area: 'Kendall' },
    { code: '33184', area: 'Kendall' },
    { code: '33185', area: 'Kendall' },
    { code: '33186', area: 'Kendall' },
    { code: '33187', area: 'Kendall' },
    { code: '33189', area: 'Kendall' },
    { code: '33190', area: 'Kendall' },
    { code: '33193', area: 'Homestead' },
    { code: '33194', area: 'Homestead' },
    { code: '33196', area: 'Kendall' }
  ];

  const bedroomOptions = [
    { value: 'Studio', label: 'Studio', icon: '🏠' },
    { value: '1', label: '1 Bedroom', icon: '🛏️' },
    { value: '2', label: '2 Bedrooms', icon: '🏡' },
    { value: '3+', label: '3+ Bedrooms', icon: '🏘️' }
  ];

  const propertyTypes = [
    { value: 'Apartment', label: 'Apartment', icon: '🏢' },
    { value: 'Single Family', label: 'Single Family', icon: '🏠' },
    { value: 'Townhouse', label: 'Townhouse', icon: '🏘️' },
    { value: 'Condo', label: 'Condo', icon: '🏙️' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="container mx-auto px-6 py-16 text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <TrendingUp className="w-10 h-10 text-blue-400" />
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
              Rental Pricing Advisor
            </h1>
          </div>
          <p className="text-2xl text-slate-300 font-medium mb-4">
            Miami-Dade County • Powered by ZORI Data
          </p>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-blue-100 leading-relaxed">
              Get Accurate Rental Pricing Based on Real Market Data. Make informed pricing decisions with actual Zillow ZORI data for Miami-Dade County. Our tool provides precise rent recommendations based on current market conditions.
            </p>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Market Analysis Section */}
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden mb-8">
            <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 px-8 py-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-6 h-6" />
                Market Analysis Overview
              </h2>
              <p className="text-emerald-100 mt-1">Powered by Zillow Observed Rent Index (ZORI)</p>
            </div>

            <div className="p-8">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
                  <div className="flex items-center gap-3 mb-3">
                    <Target className="w-8 h-8 text-blue-600" />
                    <h3 className="text-lg font-semibold text-slate-800">Precision Pricing</h3>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Our data reflects actual market conditions across {zipCodes.length} ZIP codes in Miami-Dade County, ensuring your pricing decisions are based on real rental activity.
                  </p>
                </div>

                <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-6 border border-emerald-200">
                  <div className="flex items-center gap-3 mb-3">
                    <DollarSign className="w-8 h-8 text-emerald-600" />
                    <h3 className="text-lg font-semibold text-slate-800">Market Intelligence</h3>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Access comprehensive rental data across multiple property types and bedroom configurations to optimize your rental strategy.
                  </p>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 border border-purple-200">
                  <div className="flex items-center gap-3 mb-3">
                    <TrendingUp className="w-8 h-8 text-purple-600" />
                    <h3 className="text-lg font-semibold text-slate-800">ZORI Powered</h3>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    Built on Zillow's industry-leading Observed Rent Index, providing the most accurate rental market insights available.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Property Selection */}
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Home className="w-6 h-6" />
                Property Details
              </h2>
              <p className="text-blue-100 mt-1">Select your criteria to get current market pricing</p>
            </div>

            <div className="p-8">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                {/* ZIP Code Selection */}
                <div className="space-y-3">
                  <label htmlFor="zip" className="flex items-center gap-2 text-sm font-semibold text-slate-700 uppercase tracking-wide">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    ZIP Code ({zipCodes.length} Available)
                  </label>
                  <select
                    id="zip"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white text-slate-800 font-medium"
                  >
                    {zipCodes.map((zip) => (
                      <option key={zip.code} value={zip.code}>
                        {zip.code} - {zip.area}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Bedrooms Selection */}
                <div className="space-y-3">
                  <label htmlFor="bedrooms" className="flex items-center gap-2 text-sm font-semibold text-slate-700 uppercase tracking-wide">
                    <Bed className="w-4 h-4 text-blue-600" />
                    Bedrooms
                  </label>
                  <select
                    id="bedrooms"
                    value={bedrooms}
                    onChange={(e) => setBedrooms(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white text-slate-800 font-medium"
                  >
                    {bedroomOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.icon} {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Property Type Selection */}
                <div className="space-y-3">
                  <label htmlFor="type" className="flex items-center gap-2 text-sm font-semibold text-slate-700 uppercase tracking-wide">
                    <Home className="w-4 h-4 text-blue-600" />
                    Property Type
                  </label>
                  <select
                    id="type"
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white text-slate-800 font-medium"
                  >
                    {propertyTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Results Card */}
              <div className={`bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border-2 border-blue-100 transition-all duration-300 ${isAnimating ? 'scale-95 opacity-70' : 'scale-100 opacity-100'}`}>
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-slate-700 mb-2">Current Market Analysis</h3>
                  <div className="flex items-center justify-center gap-2 text-sm text-slate-600">
                    <MapPin className="w-4 h-4" />
                    <span>{zipCodes.find(z => z.code === zipCode)?.area} ({zipCode})</span>
                    <span className="mx-2">•</span>
                    <span>{bedroomOptions.find(b => b.value === bedrooms)?.label}</span>
                    <span className="mx-2">•</span>
                    <span>{propertyTypes.find(p => p.value === propertyType)?.label}</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                    <p className="text-sm font-medium text-slate-600 mb-2">Minimum</p>
                    <p className="text-2xl font-bold text-emerald-600">{formatPrice(currentData.min)}</p>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-blue-200 relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                        Median Price
                      </span>
                    </div>
                    <p className="text-sm font-medium text-slate-600 mb-2 mt-2">Market Median</p>
                    <p className="text-4xl font-bold text-blue-600 mb-1">{formatPrice(currentData.median)}</p>
                    <p className="text-sm text-slate-500">per month</p>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
                    <p className="text-sm font-medium text-slate-600 mb-2">Maximum</p>
                    <p className="text-2xl font-bold text-rose-600">{formatPrice(currentData.max)}</p>
                  </div>
                </div>

                <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium mb-1">ZORI Data Source Information</p>
                      <p>Pricing reflects Zillow Observed Rent Index (ZORI) data for Miami-Dade County. All property type and bedroom filters show actual market variations based on current rental trends across {zipCodes.length} ZIP codes.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="text-sm">
            © 2025 SmartRentalReports.com • Market data updated monthly • Powered by Zillow ZORI
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;